<br>
<h1>Documentation</h1>

<p>Click on the PDF icon below to download the PDF file</p>
<a href="/testing9/public/documents/Documentation.pdf" download>
  <img src="/testing3/public/image/pdf.png" alt="PDF FIle" style="width:50px;height:70px;">
</a><?php /**PATH /var/www/html/testing9/resources/views/documentation.blade.php ENDPATH**/ ?>