<?php $__env->startSection('title','Admin'); ?>
<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    .alert {
        position: relative;
        padding: 0.75rem 1.25rem;
        margin-bottom: 1rem;
        border: 1px solid transparent;
        border-radius: 0.25rem;
    }
    .alert-success {
        color: #155724;
        background-color: #d4edda;
        border-color: #c3e6cb;
    }
</style>
<section class="container section-sm bg-default">

        <?php if(Session::get('success')  ): ?>
            <div class="alert alert-success text-center" id="nalert" >
                <strong><?php echo e(Session::get('success')); ?></strong>
            </div>
        <?php endif; ?>
            <div class="row" id="cuttab">
        <div class="col mb-3">
            <?php if(isset($restaurantArr[0])): ?>
            <div class=" card card-height">
                <div class="card-header bg-gray-7 clear-fix">
                    <div class="float-left"><h6>Restaurant List</h6></div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table text-center" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                            <tr>
                                <th>Sr No.</th>
                                <th>Restaurant Name</th>
                                <th>Address</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $restaurantArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td> <?php echo e($item->name); ?></td>
                                <td> <?php echo e($item->address); ?></td>
                                <td class="m-0 p-0 pt-1">
                                    <a class="btn btn-clr nbtn text-white btn-small" data-toggle="tooltip" title="Accept!" href="<?php echo e(url('approve/'.$item->id)); ?>" >
                                        <span class="fa fa-fw fa-check fa-lg"></span>
                                    </a>




                                </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
                <?php else: ?>
            <div>
                <h5>No details Found.</h5>
            </div>
                <?php endif; ?>
        </div>
    </div>
</section>
<script>
    $(document).ready(function(){
        $('[data-toggle="tooltip"]').tooltip();
    });

    $(document).ready(function() {
        $("#nalert").hide();
        $("#nalert").fadeTo(1600, 600).slideUp(600, function() {
            $("#nalert").slideUp(600);
        });
    });

</script>
<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH C:\xampp\htdocs\scc_projects\online_food_orderd\resources\views/admin.blade.php ENDPATH**/ ?>