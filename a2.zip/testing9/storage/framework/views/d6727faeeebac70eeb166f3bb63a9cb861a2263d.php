<?php $__env->startSection('title','Order'); ?>
<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    @media (min-width: 992px) {
        .product {
            height: 320px !important;
        }
    }
    img {
        width: 161px !important;
        height: 162px !important;
    }
</style>
<section class="section section-first bg-default section-style-2 text-md-left mt-1">

        <div class="container">
            <div class="row row-50">
                <div class="col-lg-10">
                    <ul class="list-xl box-typography">
                        <li>
                            <h3><?php echo e($restaurantArr->name); ?></h3>
                            <p><?php echo e($restaurantArr->address); ?></p>
                        </li>
                    </ul>
                </div>
            </div>
            <?php if(isset($dishArr[0])): ?>
            <section class="section mt-5 bg-default">
                <h3 class="oh-desktop">
                    <span class="d-inline-block wow slideInUp">Our Dishes</span></h3>
                <div class="row row-lg">
                    <?php $__currentLoopData = $dishArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-xl-2 col-offset-1 pt-2">
                            <!-- Product-->
                            <article class="product wow fadeInUp" data-wow-delay=".15s">
                                <div class="product-figure">
                                    <img src="<?php echo e(url(isset($item->d_photo)?($item->d_photo):'uploads/no-preview.jpg' )); ?>" alt="photo"/>
                                </div>
                                <h6 class="product-title"> <?php echo e($item->d_name); ?></h6>
                                <div class="product-price-wrap">
                                    <div class="product-price">$<?php echo e($item->d_prise); ?></div>
                                </div>
                                <div class="product-button">
                                    <div class="button-wrap">
                                        <?php if(auth()->guard()->guest()): ?>
                                            <?php
                                                $id = 0;
                                            ?>
                                        <?php endif; ?>
                                        <?php if(auth()->guard()->check()): ?>
                                            <?php
                                                $id =  Auth::user()->id;
                                            ?>
                                        <?php endif; ?>
                                        <a class="button button-xs button-primary button-winona" href="<?php echo e(url('/addcart/'.$id.'/'.$restaurantArr['id'].'/'.$item->id)); ?>">Add to
                                            cart</a></div>
                                </div>
                            </article>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="container">
                    <ul class="pagination justify-content-end">




                        <?php echo e($dishArr->links()); ?>

                    </ul>
                </div>
            </section>
        </div>
    <?php else: ?>
        <div class="mt-4" align="center">
            <h5>No details Found.</h5>
        </div>
    <?php endif; ?>
</section>
<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /var/www/html/Assignment2/onlineFood/resources/views/menu.blade.php ENDPATH**/ ?>