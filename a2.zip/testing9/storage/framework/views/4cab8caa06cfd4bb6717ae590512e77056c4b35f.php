</div>
<!-- Cart Modal-->
<div class="modal fade" id="cartModal" style="z-index: 1000;">
    <div class="modal-dialog modal-dialog-scrollable">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title">Cart</h4>
                <button type="button" class="close" data-dismiss="modal">×</button>
            </div>
            <!-- Modal body -->
            <div class="modal-body">
                <div class="container">
                    <?php if(isset($cartArr[0])): ?>
                        <div class="rounded nb">
                            <div class="col-md">
                                <table>
                                    <?php $__currentLoopData = $cartArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td width="70%"><?php echo e($item->d_name); ?></td>
                                            <td width="20%">$<?php echo e($item->d_prise); ?></td>
                                            <td>
                                                <a class="btn text-white btn-small" data-toggle="tooltip"
                                                   title="Remove!" href="<?php echo e(url('remove/'.$item->cart_id)); ?>"
                                                   style="background-color: #dc3545;">
                                                    <span class="fa fa-fw fa-times fa-lg"></span>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th>Total:</th>
                                        <th> $<?php echo e($cartArrsum); ?></th>
                                        <td></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="rounded nb">
                            <div class="col-md">
                                <p>No items in cart.</p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <!-- Modal footer -->
            <div class="modal-footer">
                <?php if(isset($cartArr[0])): ?>
                    <button type="submit" class="btn font-weight-bold btn-clr">
                        <a class="text-white" href="<?php echo e(url('order/'.Auth::user()->id)); ?>">Order</a>
                    </button>
                <?php endif; ?>
                <button type="button" class="btn btn-danger font-weight-bold "
                        data-dismiss="modal">Close
                </button>
            </div>
        </div>
    </div>
</div>
<!-- Javascript-->
<script src="<?php echo e(asset('js/customeJs.js')); ?>"></script>
<script src="<?php echo e(asset('js/core.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/script.js')); ?>"></script>

</body>
</html>
<?php /**PATH /var/www/html/Assignment2/onlineFood/resources/views/partials/footer.blade.php ENDPATH**/ ?>