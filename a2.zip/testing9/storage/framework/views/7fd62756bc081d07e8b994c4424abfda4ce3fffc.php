<?php $__env->startSection('title','Restaurent'); ?>
<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="container section-sm bg-default">
    <?php if(Auth::user()->is_approve == null): ?>
        <div class="alert alert-danger text-center">
            <strong>Your restaurant is not approved.</strong>
        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-xl-3 col-sm-6 my-1 ">
            <div class="card bg-gray-7">
                <div class="card-body">
                    <div class="card-body-icon clearfix">
                        <h5>Total Earning</h5>
                    </div>
                    <div class="mt-4 float-right">
                        <strong style="font-size: 2rem">$<?php echo e($sum['total']); ?></strong>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-sm-6 my-1 ">
            <div class="card bg-gray-7">
                <div class="card-body">
                    <div class="card-body-icon clearfix">
                        <h5>Last 12 Weeks</h5>
                    </div>
                    <div class="mt-4 float-right">
                        <strong style="font-size: 2rem">$<?php echo e($sum['last12']); ?></strong>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <?php $__currentLoopData = $sumArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xl-3 col-sm-6 my-1">
                <div class="card bg-gray-7">
                    <div class="card-body">
                        <div class="card-body-icon clearfix">
                            <h5>Last <?php echo e($key + 1); ?> Week</h5>
                        </div>
                        <div class="mt-4 float-right">
                            <strong style="font-size: 2rem">$<?php echo e($item); ?></strong>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /var/www/html/testing9/resources/views/restaurant.blade.php ENDPATH**/ ?>