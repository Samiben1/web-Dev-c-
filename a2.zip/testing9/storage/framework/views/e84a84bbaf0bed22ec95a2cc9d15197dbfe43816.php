<?php $__env->startSection('title','Home'); ?>
<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    img {
        height: 236px !important;
    }
</style>
<section class="section section-lg section-bottom-md-70 bg-default">
    <div class="container">
        <h3 class="oh">
            <span class="d-inline-block wow slideInUp" data-wow-delay="0s">Restaurant Near You</span>
        </h3>
        <div class="row row-lg row-40 justify-content-center">
        <?php if(isset($restaurant[0])): ?>
            <?php $__currentLoopData = $restaurant; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-6 col-lg-3 wow fadeInUp" data-wow-delay=".2s" data-wow-duration="1s">
                    <!-- Team Modern-->
                    <article class="team-modern">
                        <a class="team-modern-figure" href="<?php echo e(url('select_order/'.$item->id)); ?>">
                            <img src="<?php echo e(url(isset($item->photo)?($item->photo):'uploads/no-preview.jpg' )); ?>"
                                 alt="photo" width="270" height="236"/>
                        </a>
                        <div class="team-modern-caption">
                            <h6 class="team-modern-name">
                                <a href="<?php echo e(url('select_order/'.$item->id)); ?>"><?php echo e($item->name); ?></a>
                            </h6>
                            <ul class="list-inline team-modern-social-list text-center">
                                <li>
                                    <a class="icon px-5 py-2" style="display: inline"
                                       href="<?php echo e(url('select_order/'.$item->id)); ?>">View</a>
                                </li>
                            </ul>
                        </div>
                    </article>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php else: ?>
            <div>
                <h5>No details Found.</h5>
            </div>
        <?php endif; ?>
    </div>
</section>
</div>
<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /var/www/html/testing9/resources/views/food_home.blade.php ENDPATH**/ ?>