<?php $__env->startSection('title','Orders'); ?>
<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="container section-sm bg-default">
    <?php if(Auth::user()->is_approve == null): ?>
        <div class="alert alert-danger text-center" >
            <strong>Your restaurant is not approved.</strong>
        </div>
    <?php endif; ?>
    <div class="row" id="cuttab">
        <div class="col mb-3">
            <div class=" card card-height">
                <div class="card-header bg-gray-7 clear-fix">
                    <div class="float-left"><h6>Orders</h6></div>
                </div>
                <?php if(isset($orderArr[0])): ?>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table text-center" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                            <tr>
                                <th>Sr No.</th>
                                <th>User Name</th>
                                <th>Address</th>
                                <th>Dish Name</th>
                                <th>Prise</th>
                                <th>Date</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $orderArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td> <?php echo e($loop->iteration); ?></td>
                                <td> <?php echo e($item->name); ?></td>
                                <td> <?php echo e($item->address); ?></td>
                                <td> <?php echo e($item->d_name); ?></td>
                                <td> $<?php echo e($item->d_prise); ?></td>
                                <td> <?php echo e($item->date); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <?php else: ?>
            <div class="my-4">
                <h5>No details Found.</h5>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /var/www/html/Assignment2/onlineFood/resources/views/orders.blade.php ENDPATH**/ ?>